Die anderen beiden Dateien in diesem .zip sind die Export Dateien die alle Ihre Daten und die Import Vorlage für WP All Import enthalten.

Um diese Daten zu importieren, erstellen Sie einen neuen Import mit WP All Import und laden Sie dieses .zip hoch.